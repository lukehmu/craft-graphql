-- MySQL dump 10.16  Distrib 10.1.38-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: craftql
-- ------------------------------------------------------
-- Server version	10.1.38-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assets_filename_folderId_idx` (`filename`,`folderId`),
  KEY `assets_folderId_idx` (`folderId`),
  KEY `assets_volumeId_idx` (`volumeId`),
  CONSTRAINT `assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransformindex`
--

DROP TABLE IF EXISTS `assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransforms`
--

DROP TABLE IF EXISTS `assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_groupId_idx` (`groupId`),
  KEY `categories_parentId_fk` (`parentId`),
  CONSTRAINT `categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorygroups_name_idx` (`name`),
  KEY `categorygroups_handle_idx` (`handle`),
  KEY `categorygroups_structureId_idx` (`structureId`),
  KEY `categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `categorygroups_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_description` text,
  `field_percentage` decimal(11,1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `content_siteId_idx` (`siteId`),
  KEY `content_title_idx` (`title`),
  CONSTRAINT `content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftql_tokens`
--

DROP TABLE IF EXISTS `craftql_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftql_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `name` char(128) DEFAULT NULL,
  `token` char(64) NOT NULL,
  `scopes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `drafts_creatorId_fk` (`creatorId`),
  KEY `drafts_sourceId_fk` (`sourceId`),
  CONSTRAINT `drafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `drafts_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementindexsettings`
--

DROP TABLE IF EXISTS `elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `elements_dateDeleted_idx` (`dateDeleted`),
  KEY `elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `elements_type_idx` (`type`),
  KEY `elements_enabled_idx` (`enabled`),
  KEY `elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  KEY `elements_draftId_fk` (`draftId`),
  KEY `elements_revisionId_fk` (`revisionId`),
  CONSTRAINT `elements_draftId_fk` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `elements_revisionId_fk` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `elements_sites_siteId_idx` (`siteId`),
  KEY `elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `elements_sites_enabled_idx` (`enabled`),
  KEY `elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entries_postDate_idx` (`postDate`),
  KEY `entries_expiryDate_idx` (`expiryDate`),
  KEY `entries_authorId_idx` (`authorId`),
  KEY `entries_sectionId_idx` (`sectionId`),
  KEY `entries_typeId_idx` (`typeId`),
  KEY `entries_parentId_fk` (`parentId`),
  CONSTRAINT `entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  KEY `entrytypes_sectionId_idx` (`sectionId`),
  KEY `entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `entrytypes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouts_dateDeleted_idx` (`dateDeleted`),
  KEY `fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `fields_groupId_idx` (`groupId`),
  KEY `fields_context_idx` (`context`),
  CONSTRAINT `fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `globalsets_name_idx` (`name`),
  KEY `globalsets_handle_idx` (`handle`),
  KEY `globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `config` mediumtext,
  `configMap` mediumtext,
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocks_ownerId_idx` (`ownerId`),
  KEY `matrixblocks_fieldId_idx` (`fieldId`),
  KEY `matrixblocks_typeId_idx` (`typeId`),
  KEY `matrixblocks_sortOrder_idx` (`sortOrder`),
  CONSTRAINT `matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `migrations_pluginId_idx` (`pluginId`),
  KEY `migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `relations_sourceId_idx` (`sourceId`),
  KEY `relations_targetId_idx` (`targetId`),
  KEY `relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `revisions_sourceId_num_unq_idx` (`sourceId`,`num`),
  KEY `revisions_creatorId_fk` (`creatorId`),
  CONSTRAINT `revisions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `revisions_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sections_handle_idx` (`handle`),
  KEY `sections_name_idx` (`name`),
  KEY `sections_structureId_idx` (`structureId`),
  KEY `sections_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sessions_uid_idx` (`uid`),
  KEY `sessions_token_idx` (`token`),
  KEY `sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `sessions_userId_idx` (`userId`),
  CONSTRAINT `sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sitegroups_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sites_dateDeleted_idx` (`dateDeleted`),
  KEY `sites_handle_idx` (`handle`),
  KEY `sites_sortOrder_idx` (`sortOrder`),
  KEY `sites_groupId_fk` (`groupId`),
  CONSTRAINT `sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `structureelements_root_idx` (`root`),
  KEY `structureelements_lft_idx` (`lft`),
  KEY `structureelements_rgt_idx` (`rgt`),
  KEY `structureelements_level_idx` (`level`),
  KEY `structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taggroups_name_idx` (`name`),
  KEY `taggroups_handle_idx` (`handle`),
  KEY `taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tags_groupId_idx` (`groupId`),
  CONSTRAINT `tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecacheelements`
--

DROP TABLE IF EXISTS `templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecachequeries`
--

DROP TABLE IF EXISTS `templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `templatecachequeries_type_idx` (`type`),
  CONSTRAINT `templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecaches`
--

DROP TABLE IF EXISTS `templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_unq_idx` (`token`),
  KEY `tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_uid_idx` (`uid`),
  KEY `users_verificationCode_idx` (`verificationCode`),
  KEY `users_email_idx` (`email`),
  KEY `users_username_idx` (`username`),
  KEY `users_photoId_fk` (`photoId`),
  CONSTRAINT `users_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `volumefolders_parentId_idx` (`parentId`),
  KEY `volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `volumes_name_idx` (`name`),
  KEY `volumes_handle_idx` (`handle`),
  KEY `volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `volumes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `widgets_userId_idx` (`userId`),
  CONSTRAINT `widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'craftql'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-16 14:46:51
-- MySQL dump 10.16  Distrib 10.1.38-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: craftql
-- ------------------------------------------------------
-- Server version	10.1.38-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (3,1,1,'2-boilerplate.jpg','image',281,211,38990,NULL,NULL,NULL,'2019-08-16 13:05:48','2019-08-16 13:05:48','2019-08-16 13:05:48','caa5c89b-fe99-4ae2-91e7-6b296b1cbf59'),(9,1,1,'robin.jpg','image',960,960,43384,NULL,NULL,NULL,'2019-08-16 13:09:31','2019-08-16 13:09:31','2019-08-16 13:09:31','e452a4e2-0f36-45a2-b8b4-08b2aa01c442'),(14,1,1,'IMG-20190710-WA0013.jpg','image',1101,1600,179923,NULL,NULL,NULL,'2019-08-16 13:10:39','2019-08-16 13:10:39','2019-08-16 13:10:39','d67d12b4-b4ec-4f8b-904f-8140a6ae56d5');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assettransforms`
--

LOCK TABLES `assettransforms` WRITE;
/*!40000 ALTER TABLE `assettransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assettransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2019-08-16 12:47:04','2019-08-16 12:47:04','cc2361a6-8115-4b24-90bc-279cda5ef69f',NULL,NULL),(3,3,1,'2 boilerplate','2019-08-16 13:05:48','2019-08-16 13:05:48','8efb9c11-cd6b-4b74-84f1-ac6052a8b3b1',NULL,NULL),(4,4,1,'Iain\'s Beer','2019-08-16 13:05:56','2019-08-16 13:05:56','121c8a85-be68-436e-91c2-4c728118ccf7','Woah, that\'s a strong one',10.5),(5,5,1,'Iain\'s Beer','2019-08-16 13:05:56','2019-08-16 13:05:56','df96e51e-cfa8-43ba-8471-e270e19ecde1','Woah, that\'s a strong one',10.5),(6,6,1,'Luke\'s beer','2019-08-16 13:09:02','2019-08-16 13:09:39','7f87c373-5f99-4c8c-8d44-54e979602aae','EVEN STRONGER',12.5),(7,7,1,'Iain\'s Beer','2019-08-16 13:09:02','2019-08-16 13:09:02','34def4e8-4952-4754-9d5e-7ad514b59354','Woah, that\'s a strong one',10.5),(8,8,1,'Iain\'s Beer','2019-08-16 13:09:03','2019-08-16 13:09:03','19ede1c9-6f32-42d1-b9e0-ac621f548134','Woah, that\'s a strong one',10.5),(9,9,1,'Robin','2019-08-16 13:09:31','2019-08-16 13:09:31','6196f29f-19ea-4080-9618-1b8ffbc7c36b',NULL,NULL),(10,10,1,'Luke\'s beer','2019-08-16 13:09:39','2019-08-16 13:09:39','b673638d-eccc-48dd-add3-594c2475fd61','EVEN STRONGER',12.5),(11,11,1,'Emily\'s beer','2019-08-16 13:09:49','2019-08-16 13:10:47','fea6906f-65fa-450e-a714-9b1f5166d8cb','Fruity bad boy',5.5),(12,12,1,'Luke\'s beer','2019-08-16 13:09:49','2019-08-16 13:09:49','9f2ce54d-889f-40d1-83d8-15a2179904d2','EVEN STRONGER',12.5),(13,13,1,'Luke\'s beer','2019-08-16 13:09:49','2019-08-16 13:09:49','032df4a0-b634-4f27-a4c1-278dc61ae532','EVEN STRONGER',12.5),(14,14,1,'IMG 20190710 WA0013','2019-08-16 13:10:39','2019-08-16 13:10:39','337324f9-195b-49bc-8fe4-e51247350ceb',NULL,NULL),(15,15,1,'Emily\'s beer','2019-08-16 13:10:47','2019-08-16 13:10:47','6bab3dd6-4a6e-462f-bf50-4d90a5cdf458','Fruity bad boy',5.5);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftql_tokens`
--

LOCK TABLES `craftql_tokens` WRITE;
/*!40000 ALTER TABLE `craftql_tokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `craftql_tokens` VALUES (1,1,'everything','OG2Z3ka4w4DLdS4G2ZiXhrHQp7qjdMQUM46lHfZyOSzb7j56UY1W2PSwlcZSR0r2','{\"query:sites\":\"1\",\"query:entries\":\"1\",\"query:entry.author\":\"1\",\"query:assets\":\"1\",\"query:globals\":\"1\",\"query:categories\":\"1\",\"query:tags\":\"1\",\"query:users\":\"1\",\"query:userPermissions\":\"1\",\"query:sections\":\"1\",\"query:fields\":\"1\",\"query:entryType:1\":\"1\",\"mutate:users\":\"\",\"mutate:userPermissions\":\"\",\"mutate:globals\":\"\",\"mutate:entryType:1\":\"1\"}','2019-08-16 12:55:45','2019-08-16 13:01:59','f1de9d19-90fe-4cca-9e11-858c03cba2f5');
/*!40000 ALTER TABLE `craftql_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementindexsettings`
--

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2019-08-16 12:47:03','2019-08-16 12:47:03',NULL,'f8468f15-9f3f-45b7-b79d-f9b87d485733'),(3,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2019-08-16 13:05:48','2019-08-16 13:05:48',NULL,'0d71bb75-c302-40fc-957f-3810ce31a3f4'),(4,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:05:15','2019-08-16 13:05:56',NULL,'18d3d044-a615-4a1e-a5cd-8c0a25760e8e'),(5,NULL,1,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:05:56','2019-08-16 13:05:56',NULL,'9a221b28-839a-4aea-8247-48baff860f00'),(6,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:05:15','2019-08-16 13:09:39',NULL,'6c4c175e-d060-48e8-ad90-5b53b0196519'),(7,NULL,2,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:05:56','2019-08-16 13:05:56',NULL,'5ddcd1fd-7e40-468c-81d8-8f17f0e14f0b'),(8,NULL,3,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:09:03','2019-08-16 13:09:03',NULL,'2ff1334b-dfab-4124-b826-aa127427c516'),(9,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2019-08-16 13:09:31','2019-08-16 13:09:31',NULL,'b249488f-0d11-41c6-975d-b65f9e36203f'),(10,NULL,4,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:09:39','2019-08-16 13:09:39',NULL,'ad9dc561-3002-4cfb-8a1d-32a099173c74'),(11,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:05:15','2019-08-16 13:10:47',NULL,'6f360ae0-1d8e-4ee7-90b9-dab6dc98f72e'),(12,NULL,5,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:09:39','2019-08-16 13:09:39',NULL,'488dcd89-9271-43db-93aa-104537b6727d'),(13,NULL,6,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:09:49','2019-08-16 13:09:49',NULL,'0328e7a6-850c-45f0-93f9-08bc6375cfd8'),(14,NULL,NULL,NULL,'craft\\elements\\Asset',1,0,'2019-08-16 13:10:39','2019-08-16 13:10:39',NULL,'a7b91b66-3bf9-48d5-ae93-9871ac5d8cff'),(15,NULL,7,1,'craft\\elements\\Entry',1,0,'2019-08-16 13:10:47','2019-08-16 13:10:47',NULL,'13d47e5f-4c20-415d-a4f2-72e31ceeceb6');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2019-08-16 12:47:03','2019-08-16 12:47:03','45b94243-8cf3-4015-8a99-50e92d5159a4'),(3,3,1,NULL,NULL,1,'2019-08-16 13:05:48','2019-08-16 13:05:48','63f83e1a-7fb9-4013-bca1-d0bb2062ee1a'),(4,4,1,'iains-beer','beer/iains-beer',1,'2019-08-16 13:05:56','2019-08-16 13:05:56','ca4b4df9-5cfc-4c1b-83c4-c4517947cb77'),(5,5,1,'iains-beer','beer/iains-beer',1,'2019-08-16 13:05:56','2019-08-16 13:05:56','196e92f5-532d-4a1b-b82b-e9677f94b577'),(6,6,1,'iains-beer-1','beer/iains-beer-1',1,'2019-08-16 13:09:02','2019-08-16 13:09:02','470f1170-25cb-49d8-8d95-a4de139b1923'),(7,7,1,'iains-beer-1','beer/iains-beer-1',1,'2019-08-16 13:09:02','2019-08-16 13:09:02','f8d740f8-babb-4b46-a9fa-b453a7946e0f'),(8,8,1,'iains-beer-1','beer/iains-beer-1',1,'2019-08-16 13:09:03','2019-08-16 13:09:03','e894deef-1fa5-47f1-90ac-fd823721ff2a'),(9,9,1,NULL,NULL,1,'2019-08-16 13:09:31','2019-08-16 13:09:31','f02bd0c1-f891-4a76-8228-93d19353baad'),(10,10,1,'iains-beer-1','beer/iains-beer-1',1,'2019-08-16 13:09:39','2019-08-16 13:09:39','36c01d01-3423-4a59-a330-6ece37438cc3'),(11,11,1,'iains-beer-1-1','beer/iains-beer-1-1',1,'2019-08-16 13:09:49','2019-08-16 13:09:49','5c59b1a3-0544-4d6f-8a87-1e6a6871c3f7'),(12,12,1,'iains-beer-1-1','beer/iains-beer-1-1',1,'2019-08-16 13:09:49','2019-08-16 13:09:49','53817ca9-de0f-4f55-91d0-95e05b997803'),(13,13,1,'iains-beer-1-1','beer/iains-beer-1-1',1,'2019-08-16 13:09:49','2019-08-16 13:09:49','3aeedb16-d0f3-4f46-8334-016376c7347b'),(14,14,1,NULL,NULL,1,'2019-08-16 13:10:39','2019-08-16 13:10:39','77e1a429-15e4-412f-a297-69f1eb0ae0ca'),(15,15,1,'iains-beer-1-1','beer/iains-beer-1-1',1,'2019-08-16 13:10:47','2019-08-16 13:10:47','bef014b5-d900-4ebd-983b-e1032b711bd6');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (4,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:05:56','2019-08-16 13:05:56','662f5cda-52f0-4ba2-9340-89946be89892'),(5,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:05:56','2019-08-16 13:05:56','882c4196-0e1d-4f0d-89ff-ea72d25693de'),(6,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:09:02','2019-08-16 13:09:02','b35a603f-585f-4206-b1ec-78a69c7c407c'),(7,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:09:02','2019-08-16 13:09:02','b98a02b8-437b-48db-a72b-177069eac2e1'),(8,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:09:03','2019-08-16 13:09:03','34d37b6b-6a8b-484b-937e-a4b72115e9d7'),(10,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:09:39','2019-08-16 13:09:39','28ae4a4a-0ec4-4489-adb6-138e816a4758'),(11,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:09:49','2019-08-16 13:09:49','3835673d-46fa-4f92-a77b-149f0eeaed71'),(12,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:09:49','2019-08-16 13:09:49','b78a74ce-f16b-44a6-a0f1-ed21e9f7f79a'),(13,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:09:49','2019-08-16 13:09:49','29b49a09-30d6-4fa8-9426-fe6516c6ceca'),(15,1,NULL,1,1,'2019-08-16 13:05:00',NULL,NULL,'2019-08-16 13:10:47','2019-08-16 13:10:47','2932b0d8-9f8b-4066-9656-652b1d7ef884');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,1,'Beer','beer',1,'Title','',1,'2019-08-16 12:56:20','2019-08-16 12:56:31',NULL,'dc72437a-6cff-4b65-bdbe-3f5b6e915ad1');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2019-08-16 12:47:03','2019-08-16 12:47:03','c042f134-2319-4d71-8cc1-f07a2028fcca'),(2,'Beer','2019-08-16 12:49:05','2019-08-16 12:49:05','c86dbf63-0511-49f2-b3bb-626619ab0ef1');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (1,1,1,1,0,1,'2019-08-16 12:56:31','2019-08-16 12:56:31','d00370c9-9971-43dd-8071-e1a93f0e48ba'),(2,1,1,3,0,2,'2019-08-16 12:56:31','2019-08-16 12:56:31','4a018ce5-4d05-4386-8199-cb2de73fc5f9'),(3,1,1,2,0,3,'2019-08-16 12:56:31','2019-08-16 12:56:31','fa1a804a-7152-4d5a-8a7b-1bc076474d12');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2019-08-16 12:56:31','2019-08-16 12:56:31',NULL,'16f16ef1-4042-4729-9605-dd9befeca60e');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (1,1,'Beer',1,'2019-08-16 12:56:31','2019-08-16 12:56:31','b9aa5120-0c05-4b32-97aa-ee9004dd86ca');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,2,'Description','description','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2019-08-16 12:53:51','2019-08-16 12:53:51','592a9dcd-97bf-459e-97dc-e6d1bb1eb11e'),(2,2,'Percentage','percentage','global','',1,'none',NULL,'craft\\fields\\Number','{\"defaultValue\":null,\"min\":\"0\",\"max\":null,\"decimals\":\"1\",\"size\":null,\"prefix\":\"\",\"suffix\":\"%\"}','2019-08-16 12:55:01','2019-08-16 12:55:01','ffec6a78-d4ba-4d3e-8404-8225b52e6794'),(3,2,'Image','image','global','',1,'site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:6b1c14cb-cafc-4879-876e-eb3dab3e3e20\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:6b1c14cb-cafc-4879-876e-eb3dab3e3e20\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"allowedKinds\":null,\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"}','2019-08-16 12:55:23','2019-08-16 12:55:23','cb14819b-9de9-4c0f-8e87-c0eff6171df5');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'3.2.10','3.2.16',0,'{\"fieldGroups\":{\"c042f134-2319-4d71-8cc1-f07a2028fcca\":{\"name\":\"Common\"},\"c86dbf63-0511-49f2-b3bb-626619ab0ef1\":{\"name\":\"Beer\"}},\"siteGroups\":{\"45728071-e9db-4b8e-ad6c-b3602440ba53\":{\"name\":\"CraftQL\"}},\"sites\":{\"b81980d2-950b-45e5-b2e0-e463dc83017d\":{\"baseUrl\":\"$DEFAULT_SITE_URL\",\"handle\":\"default\",\"hasUrls\":true,\"language\":\"en-GB\",\"name\":\"CraftQL\",\"primary\":true,\"siteGroup\":\"45728071-e9db-4b8e-ad6c-b3602440ba53\",\"sortOrder\":1}},\"email\":{\"fromEmail\":\"lukehmu@gmail.com\",\"fromName\":\"CraftQL\",\"transportType\":\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"},\"system\":{\"edition\":\"solo\",\"name\":\"CraftQL\",\"live\":true,\"schemaVersion\":\"3.2.16\",\"timeZone\":\"America/Los_Angeles\"},\"users\":{\"requireEmailVerification\":true,\"allowPublicRegistration\":false,\"defaultGroup\":null,\"photoVolumeUid\":null,\"photoSubpath\":\"\"},\"dateModified\":1565960919,\"plugins\":{\"craftql\":{\"edition\":\"standard\",\"enabled\":true,\"schemaVersion\":\"1.1.0\"}},\"fields\":{\"592a9dcd-97bf-459e-97dc-e6d1bb1eb11e\":{\"name\":\"Description\",\"handle\":\"description\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\PlainText\",\"settings\":{\"placeholder\":\"\",\"code\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"},\"contentColumnType\":\"text\",\"fieldGroup\":\"c86dbf63-0511-49f2-b3bb-626619ab0ef1\"},\"ffec6a78-d4ba-4d3e-8404-8225b52e6794\":{\"name\":\"Percentage\",\"handle\":\"percentage\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"none\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Number\",\"settings\":{\"defaultValue\":null,\"min\":\"0\",\"max\":null,\"decimals\":\"1\",\"size\":null,\"prefix\":\"\",\"suffix\":\"%\"},\"contentColumnType\":\"decimal(11,1)\",\"fieldGroup\":\"c86dbf63-0511-49f2-b3bb-626619ab0ef1\"},\"cb14819b-9de9-4c0f-8e87-c0eff6171df5\":{\"name\":\"Image\",\"handle\":\"image\",\"instructions\":\"\",\"searchable\":true,\"translationMethod\":\"site\",\"translationKeyFormat\":null,\"type\":\"craft\\\\fields\\\\Assets\",\"settings\":{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"volume:6b1c14cb-cafc-4879-876e-eb3dab3e3e20\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"volume:6b1c14cb-cafc-4879-876e-eb3dab3e3e20\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"allowedKinds\":null,\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"1\",\"selectionLabel\":\"\",\"localizeRelations\":false,\"validateRelatedElements\":\"\"},\"contentColumnType\":\"string\",\"fieldGroup\":\"c86dbf63-0511-49f2-b3bb-626619ab0ef1\"}},\"volumes\":{\"6b1c14cb-cafc-4879-876e-eb3dab3e3e20\":{\"name\":\"Local assets\",\"handle\":\"localAssets\",\"type\":\"craft\\\\volumes\\\\Local\",\"hasUrls\":true,\"url\":\"@web/localAssets\",\"settings\":{\"path\":\"localAssets\"},\"sortOrder\":1}},\"sections\":{\"086d7a9c-26ab-48af-8d4e-5918713e3b99\":{\"name\":\"Beer\",\"handle\":\"beer\",\"type\":\"channel\",\"enableVersioning\":true,\"propagationMethod\":\"all\",\"siteSettings\":{\"b81980d2-950b-45e5-b2e0-e463dc83017d\":{\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"beer/{slug}\",\"template\":\"\"}},\"entryTypes\":{\"dc72437a-6cff-4b65-bdbe-3f5b6e915ad1\":{\"name\":\"Beer\",\"handle\":\"beer\",\"hasTitleField\":true,\"titleLabel\":\"Title\",\"titleFormat\":\"\",\"sortOrder\":1,\"fieldLayouts\":{\"16f16ef1-4042-4729-9605-dd9befeca60e\":{\"tabs\":[{\"name\":\"Beer\",\"sortOrder\":1,\"fields\":{\"592a9dcd-97bf-459e-97dc-e6d1bb1eb11e\":{\"required\":false,\"sortOrder\":1},\"cb14819b-9de9-4c0f-8e87-c0eff6171df5\":{\"required\":false,\"sortOrder\":2},\"ffec6a78-d4ba-4d3e-8404-8225b52e6794\":{\"required\":false,\"sortOrder\":3}}}]}}}}}}}','[]','dgpRBEbRuMeI','2019-08-16 12:47:03','2019-08-16 12:47:03','30d808fd-c51c-492b-aeeb-2502bc33bca5');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,NULL,'app','Install','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','fbc306af-2edd-4367-926c-ecb0f8523036'),(2,NULL,'app','m150403_183908_migrations_table_changes','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','3a5da8bb-fe9d-40f9-9a02-b40d3db2e201'),(3,NULL,'app','m150403_184247_plugins_table_changes','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','60fb58c2-c6af-4c7c-aecb-8223f573d78e'),(4,NULL,'app','m150403_184533_field_version','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','8b9f079c-eeed-4ca9-a24e-ae81f5ffbe16'),(5,NULL,'app','m150403_184729_type_columns','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','3fb45f51-b89c-47ed-887b-18cd118dccfd'),(6,NULL,'app','m150403_185142_volumes','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','bcc88ceb-b909-4541-ae35-0cd54456dc32'),(7,NULL,'app','m150428_231346_userpreferences','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','49d9deb2-134a-4b47-9a84-f12074a0b566'),(8,NULL,'app','m150519_150900_fieldversion_conversion','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','0ab58a7a-5b7a-4e3b-94f1-44220926ea5a'),(9,NULL,'app','m150617_213829_update_email_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','c94d4936-1c89-47f7-8499-11fa278e606a'),(10,NULL,'app','m150721_124739_templatecachequeries','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','757b20b8-2a8a-4d16-bb39-9d6edbc2477d'),(11,NULL,'app','m150724_140822_adjust_quality_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','c7f9a67e-b38f-4900-bd65-a363f9f8c611'),(12,NULL,'app','m150815_133521_last_login_attempt_ip','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','abba998e-5f5f-41d6-9506-94305c0d5dc2'),(13,NULL,'app','m151002_095935_volume_cache_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','f21e621e-380a-4483-bae2-800b3829b791'),(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','015a97de-a3d1-40af-8e0d-a2fbc458f64d'),(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','50083603-9b72-425e-af40-2ae7d25fafb8'),(16,NULL,'app','m151209_000000_move_logo','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','56a8efb4-eb05-42e5-b1cf-b9c57e3a22c1'),(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','89ed007e-6b20-4684-9bf6-8104b0ec7358'),(18,NULL,'app','m151215_000000_rename_asset_permissions','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','1a3370d8-d251-4ad3-8833-29610d2cfb26'),(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','e3efdd56-3888-4690-8307-75183f3b4a1b'),(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','db804a71-897e-4cef-a0ad-5f3fcc89d2dd'),(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','1f357832-7ab0-4ad2-9ff4-c5a2cdba9970'),(22,NULL,'app','m160727_194637_column_cleanup','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','c97950e8-7568-4463-8d10-1bfd0fd52f5f'),(23,NULL,'app','m160804_110002_userphotos_to_assets','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','4ccd3cb7-b45d-402b-93cc-1f62a8bf28ea'),(24,NULL,'app','m160807_144858_sites','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','19f85706-7a50-4bfe-9c64-0dd54cc546b0'),(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','3772570a-6e2b-44ff-90c1-9bda1bb3e55b'),(26,NULL,'app','m160830_000000_asset_index_uri_increase','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','6aca52b5-2fae-463d-b30c-69633cf7eeb8'),(27,NULL,'app','m160912_230520_require_entry_type_id','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','13b850dc-f145-42f3-ae26-6e24fdd5d28f'),(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','6a3376a4-0eb0-46ac-a4d3-bc6e8f7c8aa2'),(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','5d5cc3c1-63db-424a-8770-f6eba4aa01db'),(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','c74989e9-7e2b-492b-83bf-249ceb743fb8'),(31,NULL,'app','m160925_113941_route_uri_parts','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','ebe41a0d-5ed5-47da-8ca6-16745a70cf4f'),(32,NULL,'app','m161006_205918_schemaVersion_not_null','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','134ff9b2-bd29-4781-ab12-ca61c2290eda'),(33,NULL,'app','m161007_130653_update_email_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','6c247e4b-ae42-4af2-aaec-4f1765cdb550'),(34,NULL,'app','m161013_175052_newParentId','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','9b64e16c-0fff-47d9-8a84-8b89e94d6b19'),(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','ede5312e-8e6e-4a3a-9aa2-8eb6ddc7df27'),(36,NULL,'app','m161021_182140_rename_get_help_widget','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','3ad720d8-56d6-416d-9456-d464aa2c63e5'),(37,NULL,'app','m161025_000000_fix_char_columns','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','ee2a041c-aaed-4ceb-84c4-f2384dfca56e'),(38,NULL,'app','m161029_124145_email_message_languages','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','e93cea5e-3028-4e55-b01e-fc944ff5088e'),(39,NULL,'app','m161108_000000_new_version_format','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','d25911d1-07e0-44a3-931b-052fb3d218ee'),(40,NULL,'app','m161109_000000_index_shuffle','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','cadef990-2003-4c2f-8f0a-9b8363a25868'),(41,NULL,'app','m161122_185500_no_craft_app','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','b4ad224a-4b60-4fd7-bdbc-4f3bbac9c6d7'),(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','6c00310d-c720-4793-ae27-12db6e4f9060'),(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','3de8a6f8-08e5-4087-bea9-109a6bf43c97'),(44,NULL,'app','m170114_161144_udates_permission','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','03f2d358-97ec-4048-aa6f-ef600f407bcb'),(45,NULL,'app','m170120_000000_schema_cleanup','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','b436cef1-9fe6-4384-be5b-74f888967e72'),(46,NULL,'app','m170126_000000_assets_focal_point','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','2a106e37-7e4d-4d98-8945-1ac071a406c6'),(47,NULL,'app','m170206_142126_system_name','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','c634642e-ac7b-4e8a-985b-acc255511a31'),(48,NULL,'app','m170217_044740_category_branch_limits','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','b7a199f7-42e7-4550-801d-e8e4f494f8b8'),(49,NULL,'app','m170217_120224_asset_indexing_columns','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','711b03c0-ec33-4e13-81f5-a17c428eec5d'),(50,NULL,'app','m170223_224012_plain_text_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','2a26712a-1c37-4eae-8538-d7616b2f7bb9'),(51,NULL,'app','m170227_120814_focal_point_percentage','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','48c0adb7-e3ff-4114-81ee-35feec98261f'),(52,NULL,'app','m170228_171113_system_messages','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','064d9f39-ba33-490a-b18a-913b4c59fbd7'),(53,NULL,'app','m170303_140500_asset_field_source_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','47efbc64-b3b0-4203-868f-d9be46f2c93d'),(54,NULL,'app','m170306_150500_asset_temporary_uploads','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','5e2e82f8-54f3-4255-bc18-835eff5d3e2f'),(55,NULL,'app','m170523_190652_element_field_layout_ids','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','fc1313fa-1cb7-4f49-8c1e-87c01542c05b'),(56,NULL,'app','m170612_000000_route_index_shuffle','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','c9451dd7-9bec-471a-8997-e3164ade809b'),(57,NULL,'app','m170621_195237_format_plugin_handles','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','358ea183-a094-4a63-9f2f-a9f3e350ff32'),(58,NULL,'app','m170630_161027_deprecation_line_nullable','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','aeaf2193-6a9d-4502-bf72-b425f13cfeef'),(59,NULL,'app','m170630_161028_deprecation_changes','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','8d43de1f-b685-467a-8e36-d50a0b0d922f'),(60,NULL,'app','m170703_181539_plugins_table_tweaks','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','4dd3ade4-06db-4ceb-9dbc-5ba71e28ad27'),(61,NULL,'app','m170704_134916_sites_tables','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','e17f8074-4915-46d6-bb50-3c57bc93792c'),(62,NULL,'app','m170706_183216_rename_sequences','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','2c15484b-f179-4d6b-93fd-b9476f2c9efe'),(63,NULL,'app','m170707_094758_delete_compiled_traits','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','904621d9-ab29-4370-af42-beb5bfc34487'),(64,NULL,'app','m170731_190138_drop_asset_packagist','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','3b6c46b4-b453-44c1-bcbb-f1a61f7f022e'),(65,NULL,'app','m170810_201318_create_queue_table','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','4f1bbd77-cd65-4182-a938-24128b96fff4'),(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','43f4b8c5-8ef8-4c8d-9e1b-de7c0bacccb5'),(67,NULL,'app','m170903_192801_longblob_for_queue_jobs','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','39518e14-72d7-4063-aa72-da2e6217ecea'),(68,NULL,'app','m170914_204621_asset_cache_shuffle','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','4be4ca2b-b195-4824-be1e-43eac5435d27'),(69,NULL,'app','m171011_214115_site_groups','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','95475797-7c06-49a2-ae41-67d1a61343b7'),(70,NULL,'app','m171012_151440_primary_site','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','bda034f1-bdb1-4697-99de-8fe26b3f50b0'),(71,NULL,'app','m171013_142500_transform_interlace','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','6bfff242-3576-4fb6-91a5-d436fca54cab'),(72,NULL,'app','m171016_092553_drop_position_select','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','bb87411b-3daa-4a6b-8dd5-e114e4ae7b5c'),(73,NULL,'app','m171016_221244_less_strict_translation_method','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','2b7e6f58-0c2c-4a50-bc61-6d00fded1892'),(74,NULL,'app','m171107_000000_assign_group_permissions','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','ccd1cd9d-e556-4f45-8fed-44d4f6dc6fbd'),(75,NULL,'app','m171117_000001_templatecache_index_tune','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','6990f85e-aba2-47f1-9d54-7bed6a2deb60'),(76,NULL,'app','m171126_105927_disabled_plugins','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','cc730869-30ed-4308-81f7-ed6f81f3df13'),(77,NULL,'app','m171130_214407_craftidtokens_table','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','8a35162f-68c4-458e-90a2-43f33b5917c8'),(78,NULL,'app','m171202_004225_update_email_settings','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','a77c83fb-ca41-4c38-80f9-57a04829cdc8'),(79,NULL,'app','m171204_000001_templatecache_index_tune_deux','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','30656728-c4e3-423e-855a-84e52b970eaf'),(80,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','4e79a2ba-9d33-42e6-a2a0-bc5c4d55bd9e'),(81,NULL,'app','m171218_143135_longtext_query_column','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','26a55487-5fd6-4f1a-9cc5-dd00f0b82aa0'),(82,NULL,'app','m171231_055546_environment_variables_to_aliases','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','852e3c5b-eefb-4708-8b6a-ef4ce9a9e90a'),(83,NULL,'app','m180113_153740_drop_users_archived_column','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','dcecfa67-6fdd-4d96-aa32-00f18a746bb3'),(84,NULL,'app','m180122_213433_propagate_entries_setting','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','25bcd3cc-ec38-46cc-a4a4-f668840d03e5'),(85,NULL,'app','m180124_230459_fix_propagate_entries_values','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','d1af192d-2989-4959-8da0-aff4014a1f7b'),(86,NULL,'app','m180128_235202_set_tag_slugs','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','7a9a3a64-9e69-4961-96a5-36a060c42f6c'),(87,NULL,'app','m180202_185551_fix_focal_points','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','634e3c0c-de06-4796-a5de-b87f3e1cbf02'),(88,NULL,'app','m180217_172123_tiny_ints','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','402d0862-2aef-4054-a44e-c898e8bda86e'),(89,NULL,'app','m180321_233505_small_ints','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','8cbbe9a0-6e38-48d8-b49d-2d7c1e4c9a72'),(90,NULL,'app','m180328_115523_new_license_key_statuses','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','ec3bd7d5-41e2-4493-8aa8-8692a56ca196'),(91,NULL,'app','m180404_182320_edition_changes','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','146ea728-989e-4b76-a4c6-97bb4ad462f3'),(92,NULL,'app','m180411_102218_fix_db_routes','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','662db968-6eff-4ff9-b131-43cef32766db'),(93,NULL,'app','m180416_205628_resourcepaths_table','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','ca35b4af-c70e-4406-bd20-88af8a728946'),(94,NULL,'app','m180418_205713_widget_cleanup','2019-08-16 12:47:05','2019-08-16 12:47:05','2019-08-16 12:47:05','7b65b8b0-f280-4d6c-9c04-20242fb07c08'),(95,NULL,'app','m180425_203349_searchable_fields','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','8f2ee7fd-790d-4b1e-bb18-9e46cb093a36'),(96,NULL,'app','m180516_153000_uids_in_field_settings','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','1e3c14cb-2d99-4d40-8aba-677f35fb2aa3'),(97,NULL,'app','m180517_173000_user_photo_volume_to_uid','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','9947686e-5023-470b-a374-331e4cee9e41'),(98,NULL,'app','m180518_173000_permissions_to_uid','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','9954e2a0-063f-4f8e-8102-71acb93f490d'),(99,NULL,'app','m180520_173000_matrix_context_to_uids','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','9c0ced37-d200-4e9b-8157-989c148bab31'),(100,NULL,'app','m180521_173000_initial_yml_and_snapshot','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','56ffdbe7-695f-4869-9a9d-df69131e6cb0'),(101,NULL,'app','m180731_162030_soft_delete_sites','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','92e2366f-ab09-4eb1-ace3-72f4ebd96e64'),(102,NULL,'app','m180810_214427_soft_delete_field_layouts','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','74c3ad3f-4539-4109-b509-bb44957b0ce4'),(103,NULL,'app','m180810_214439_soft_delete_elements','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','bb193bbd-f412-45b9-bba7-15c3a2117649'),(104,NULL,'app','m180824_193422_case_sensitivity_fixes','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','fcca7075-78be-49b9-8399-bd01bfecf5c0'),(105,NULL,'app','m180901_151639_fix_matrixcontent_tables','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','71887e09-372f-49c4-9974-a7626f2c8ede'),(106,NULL,'app','m180904_112109_permission_changes','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','3ad6b6be-505b-447b-abcd-05bcd019cbbb'),(107,NULL,'app','m180910_142030_soft_delete_sitegroups','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','9bce3879-0f0b-4ba8-a53a-83279e4de62f'),(108,NULL,'app','m181011_160000_soft_delete_asset_support','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','85f3ddfa-0d53-4a45-a483-1ade6555cadb'),(109,NULL,'app','m181016_183648_set_default_user_settings','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','f7770097-062c-46d3-8121-7e9e69707ed2'),(110,NULL,'app','m181017_225222_system_config_settings','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','03bbffa3-e9aa-4a51-abea-be05a7180ef1'),(111,NULL,'app','m181018_222343_drop_userpermissions_from_config','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','1973855e-b9f0-47d2-906f-39f91329c941'),(112,NULL,'app','m181029_130000_add_transforms_routes_to_config','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','28d1c480-1d81-42ed-8868-4a5121855d72'),(113,NULL,'app','m181112_203955_sequences_table','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','688fa6c2-9ceb-478e-acf6-37363f1f2f68'),(114,NULL,'app','m181121_001712_cleanup_field_configs','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','43f96a0a-be44-4c75-93b7-ca32b4040f54'),(115,NULL,'app','m181128_193942_fix_project_config','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','1ecfe85d-f3e7-49f4-af49-84b04fd5fda1'),(116,NULL,'app','m181130_143040_fix_schema_version','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','8caf1ca8-7203-4150-a266-1db7cd712b5f'),(117,NULL,'app','m181211_143040_fix_entry_type_uids','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','11ef3aa2-22fd-4815-bca0-922f604627dc'),(118,NULL,'app','m181213_102500_config_map_aliases','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','dc56cdc9-c4c5-4ac0-ad5a-7c793894ef49'),(119,NULL,'app','m181217_153000_fix_structure_uids','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','e467cffe-0b6f-4f0d-9600-d3c7929590fd'),(120,NULL,'app','m190104_152725_store_licensed_plugin_editions','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','ccdbe848-061c-4cfa-b96d-1756b399bb15'),(121,NULL,'app','m190108_110000_cleanup_project_config','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','12a039b0-aa9f-43ae-a9f5-f3e6fa74ea93'),(122,NULL,'app','m190108_113000_asset_field_setting_change','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','1fc52756-0c98-4821-86a3-5b2a16fe8ff6'),(123,NULL,'app','m190109_172845_fix_colspan','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','ef4fe9ef-b9cf-47dc-9887-bb863d29eceb'),(124,NULL,'app','m190110_150000_prune_nonexisting_sites','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','68a2f3da-8fec-4130-b4f0-8cfdf2db9505'),(125,NULL,'app','m190110_214819_soft_delete_volumes','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','2d5b7a03-68f6-4bdc-a834-639a07666944'),(126,NULL,'app','m190112_124737_fix_user_settings','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','e35c3c71-1c6f-4420-b8ad-9277f7f8462a'),(127,NULL,'app','m190112_131225_fix_field_layouts','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','60630148-5814-40e8-b592-781e7f034340'),(128,NULL,'app','m190112_201010_more_soft_deletes','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','864247e8-c9c9-4bad-85ad-74af6cce4bb3'),(129,NULL,'app','m190114_143000_more_asset_field_setting_changes','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','e2e0e3a9-810f-483f-ba62-458df5f8c050'),(130,NULL,'app','m190121_120000_rich_text_config_setting','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','ad0f589d-9c54-4e1e-b557-335af05be185'),(131,NULL,'app','m190125_191628_fix_email_transport_password','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','c9aa2a60-f30f-4dc5-85d8-a1034c96a356'),(132,NULL,'app','m190128_181422_cleanup_volume_folders','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','c8250d18-9625-45ec-b448-29ac633ee98e'),(133,NULL,'app','m190205_140000_fix_asset_soft_delete_index','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','3729adff-d2e9-41bf-bd14-105c47205517'),(134,NULL,'app','m190208_140000_reset_project_config_mapping','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','deb47009-575d-451f-aed6-4c9ef225ff9d'),(135,NULL,'app','m190218_143000_element_index_settings_uid','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','aae01703-6dac-4ce7-90e9-ec773c415630'),(136,NULL,'app','m190312_152740_element_revisions','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','73797bc6-358f-4fb9-8cd4-755d27e0225d'),(137,NULL,'app','m190327_235137_propagation_method','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','d88c088a-0764-4122-a725-f47979c564da'),(138,NULL,'app','m190401_223843_drop_old_indexes','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','4f88e468-7a22-4a00-aefe-7f00f8228042'),(139,NULL,'app','m190416_014525_drop_unique_global_indexes','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','57e93206-7d51-4b85-870f-9492c4b8cc65'),(140,NULL,'app','m190417_085010_add_image_editor_permissions','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','ce092706-5550-4dd3-991e-0b5cff029675'),(141,NULL,'app','m190502_122019_store_default_user_group_uid','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','ab96d61d-da7d-437e-8b29-2efd2102bca3'),(142,NULL,'app','m190504_150349_preview_targets','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','2ec75cfa-00c4-459e-9494-2bc5e79d5dbb'),(143,NULL,'app','m190516_184711_job_progress_label','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','39ccc63f-6424-44e6-8dd1-a29b9d01854c'),(144,NULL,'app','m190523_190303_optional_revision_creators','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','94c6cb67-9d1f-44d2-8b53-092c3e04bf7d'),(145,NULL,'app','m190529_204501_fix_duplicate_uids','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','30a77ebe-97f1-4c97-9447-b715e06a2fff'),(146,NULL,'app','m190605_223807_unsaved_drafts','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','32ea18e8-15a0-4f95-a403-6a1c2289a488'),(147,NULL,'app','m190607_230042_entry_revision_error_tables','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','caa354a3-c56b-403b-96f4-fef177f15318'),(148,NULL,'app','m190608_033429_drop_elements_uid_idx','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','07d24c81-b1c2-4bdd-b914-82846d10ce45'),(149,NULL,'app','m190624_234204_matrix_propagation_method','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','48fef0b2-86e5-4935-bfc0-f4de63e0ce49'),(150,NULL,'app','m190711_153020_drop_snapshots','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','878d0e5c-4651-4968-98c6-190d6eeb455c'),(151,NULL,'app','m190712_195914_no_draft_revisions','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','1ac1edfa-d658-4316-92b2-90a6d4af9c4a'),(152,NULL,'app','m190723_140314_fix_preview_targets_column','2019-08-16 12:47:06','2019-08-16 12:47:06','2019-08-16 12:47:06','222d7d98-c5fc-4e5f-91e4-38ef28172f6c'),(153,1,'plugin','Install','2019-08-16 12:53:17','2019-08-16 12:53:17','2019-08-16 12:53:17','1881b210-f560-450f-9a5a-ca86ace81098'),(154,1,'plugin','m170804_170613_add_scopes','2019-08-16 12:53:17','2019-08-16 12:53:17','2019-08-16 12:53:17','9769db81-693a-4419-b9bc-1201979c174d');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'craftql','1.3.2','1.1.0','invalid',NULL,'2019-08-16 12:53:17','2019-08-16 12:53:17','2019-08-16 12:53:36','b4788605-e8a9-464b-a666-53cd99473ed0');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (2,3,4,NULL,3,1,'2019-08-16 13:05:56','2019-08-16 13:05:56','ed072050-9261-4ceb-aa91-bc9e59b0ba6b'),(3,3,5,NULL,3,1,'2019-08-16 13:05:56','2019-08-16 13:05:56','1cbfd3df-fb46-4d59-b590-63b4d401830c'),(5,3,7,NULL,3,1,'2019-08-16 13:09:02','2019-08-16 13:09:02','0ad11dfa-70e0-4e94-a8bb-01c70fab0170'),(7,3,8,NULL,3,1,'2019-08-16 13:09:03','2019-08-16 13:09:03','720f209c-1a10-4a15-a06d-f517e5577dce'),(8,3,6,NULL,9,1,'2019-08-16 13:09:39','2019-08-16 13:09:39','2f245387-3b4a-45f2-98a0-afe635642b02'),(9,3,10,NULL,9,1,'2019-08-16 13:09:39','2019-08-16 13:09:39','9e30657d-3217-4d86-bb03-1a8a0e234bd8'),(11,3,12,NULL,9,1,'2019-08-16 13:09:49','2019-08-16 13:09:49','5bd79648-8e63-4fa9-904d-d52c726649cd'),(13,3,13,NULL,9,1,'2019-08-16 13:09:49','2019-08-16 13:09:49','c7111206-6ec5-4a8b-93a7-fa897e1883ca'),(14,3,11,NULL,14,1,'2019-08-16 13:10:47','2019-08-16 13:10:47','2df58d3d-c7ec-4cd2-8de9-442649e95f89'),(15,3,15,NULL,14,1,'2019-08-16 13:10:47','2019-08-16 13:10:47','ecee8f15-bf5a-4d3f-89e5-839ddf8f7885');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `resourcepaths` VALUES ('127259e0','@craft/web/assets/pluginstore/dist'),('1314aa72','@app/web/assets/installer/dist'),('186c814d','@craft/web/assets/updateswidget/dist'),('1e56678e','@craft/web/assets/feed/dist'),('21435aca','@craft/web/assets/craftsupport/dist'),('26d6c323','@craft/web/assets/recententries/dist'),('2bd47dc6','@craft/web/assets/dbbackup/dist'),('3ffababe','@app/web/assets/cp/dist'),('47b38345','@craft/web/assets/editentry/dist'),('4b3ced13','@lib/velocity'),('50cac860','@craft/web/assets/tablesettings/dist'),('571b42fb','@lib/jquery.payment'),('58e06016','@craft/web/assets/utilities/dist'),('591e26c2','@markhuot/CraftQL/resources'),('59576b6','@lib/jquery-ui'),('5ab31a6e','@bower/jquery/dist'),('5e0ee258','@lib/element-resize-detector'),('5ffac041','@app/web/assets/feed/dist'),('67154145','@craft/web/assets/dashboard/dist'),('7b82ead7','@lib'),('82670b6d','@lib/selectize'),('858a4413','@craft/web/assets/cp/dist'),('8bc091ad','@app/web/assets/updater/dist'),('91107ea6','@lib/xregexp'),('91ed2e84','@craft/web/assets/installer/dist'),('9b95c392','@app/web/assets/updateswidget/dist'),('a52f81fc','@app/web/assets/recententries/dist'),('a547824e','@app/web/assets/login/dist'),('b0e9ffb2','@lib/datepicker-i18n'),('b7f41792','@lib/timepicker'),('b8442dd','@app/web/assets/craftsupport/dist'),('ba41da1b','@app/web/assets/pluginstore/dist'),('cef12717','@lib/fileupload'),('d1bd1a2b','@lib/jquery-touch-events'),('d3338abf','@app/web/assets/tablesettings/dist'),('d33b10a2','@lib/prismjs'),('d61926e9','@lib/picturefill'),('e28bebfd','@app/web/assets/fields/dist'),('e5ecc5b3','@app/web/assets/dashboard/dist'),('e65b579b','@craft/web/assets/fields/dist'),('e9a888e1','@app/web/assets/matrixsettings/dist'),('eb01113e','@lib/garnishjs'),('f391557b','@lib/d3'),('fe47c500','@lib/fabric'),('ff47bee6','@craft/web/assets/matrixsettings/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,4,1,1,NULL),(2,6,1,1,NULL),(3,6,1,2,NULL),(4,6,1,3,NULL),(5,11,1,1,NULL),(6,11,1,2,NULL),(7,11,1,3,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'username',0,1,' admin '),(1,'firstname',0,1,''),(1,'lastname',0,1,''),(1,'fullname',0,1,''),(1,'email',0,1,' lukehmu gmail com '),(1,'slug',0,1,''),(3,'filename',0,1,' 2 boilerplate jpg '),(3,'extension',0,1,' jpg '),(3,'kind',0,1,' image '),(3,'slug',0,1,''),(3,'title',0,1,' 2 boilerplate '),(4,'slug',0,1,' iains beer '),(4,'title',0,1,' iain s beer '),(4,'field',1,1,' woah that s a strong one '),(4,'field',3,1,' 2 boilerplate '),(4,'field',2,1,' 10 5 '),(6,'slug',0,1,' iains beer 1 '),(6,'title',0,1,' luke s beer '),(6,'field',1,1,' even stronger '),(6,'field',3,1,' robin '),(6,'field',2,1,' 12 5 '),(9,'filename',0,1,' robin jpg '),(9,'extension',0,1,' jpg '),(9,'kind',0,1,' image '),(9,'slug',0,1,''),(9,'title',0,1,' robin '),(11,'slug',0,1,' iains beer 1 1 '),(11,'title',0,1,' emily s beer '),(11,'field',1,1,' fruity bad boy '),(11,'field',3,1,' img 20190710 wa0013 '),(11,'field',2,1,' 5 5 '),(14,'filename',0,1,' img 20190710 wa0013 jpg '),(14,'extension',0,1,' jpg '),(14,'kind',0,1,' image '),(14,'slug',0,1,''),(14,'title',0,1,' img 20190710 wa0013 ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Beer','beer','channel',1,'all',NULL,'2019-08-16 12:56:20','2019-08-16 12:56:31',NULL,'086d7a9c-26ab-48af-8d4e-5918713e3b99');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'beer/{slug}','',1,'2019-08-16 12:56:20','2019-08-16 12:56:31','50eeeacf-57ec-48a3-952e-d8194d125a0d');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'CraftQL','2019-08-16 12:47:03','2019-08-16 12:47:03',NULL,'45728071-e9db-4b8e-ad6c-b3602440ba53');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'CraftQL','default','en-GB',1,'$DEFAULT_SITE_URL',1,'2019-08-16 12:47:03','2019-08-16 12:47:03',NULL,'b81980d2-950b-45e5-b2e0-e463dc83017d');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-GB\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,'admin',NULL,NULL,NULL,'lukehmu@gmail.com','$2y$13$xPwrl28TS.Uf/5rCvZoX0eKEnfkg1idZDN8J186QMdq4gdKWVTpHi',1,0,0,0,'2019-08-16 12:48:31',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2019-08-16 12:47:04','2019-08-16 12:47:04','2019-08-16 12:48:35','da44c412-0026-4883-9157-3280f95ba435');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Local assets','','2019-08-16 12:54:43','2019-08-16 13:08:39','d96aa941-10e9-49a2-a131-e8355c32bbce'),(2,NULL,NULL,'Temporary source',NULL,'2019-08-16 13:05:37','2019-08-16 13:05:37','f946556f-7fa6-4b01-89e2-4228fb3e478b'),(3,2,NULL,'user_1','user_1/','2019-08-16 13:05:37','2019-08-16 13:05:37','486fbf3e-6902-4ecb-a9a3-fe98dd7fdcf6');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,NULL,'Local assets','localAssets','craft\\volumes\\Local',1,'@web/localAssets','{\"path\":\"localAssets\"}',1,'2019-08-16 12:54:43','2019-08-16 13:08:39',NULL,'6b1c14cb-cafc-4879-876e-eb3dab3e3e20');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}',1,'2019-08-16 12:48:35','2019-08-16 12:48:35','ca348c4f-fc46-4d69-96e7-4f69caf7c592'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2019-08-16 12:48:35','2019-08-16 12:48:35','4cc287fb-02f4-42e7-9454-b57d647adb56'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2019-08-16 12:48:35','2019-08-16 12:48:35','6b129248-c337-480a-8c9f-2fbef0ba7d9a'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2019-08-16 12:48:35','2019-08-16 12:48:35','78c0ca30-da4a-453e-a159-80f3f7d67f23');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'craftql'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-16 14:46:52
